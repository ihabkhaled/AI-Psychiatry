# Publisher Checklist

Status: release `0.3.0` is being finalized directly on `main`; vendor submission and approval must remain unclaimed until authenticated receipts exist.

Evidence recorded 2026-08-14:

- Targeted semantic compliance and asset regressions pass during implementation; final complete-suite results are recorded after the release archive is built.
- The canonical 0-189 master prompt remains byte-for-byte unchanged; loophole and underthinking prompts are supplemental, progressively disclosed references.
- Baseline pressure tests found the existing framework already resisted core command/label laundering, false completion/blockers, and hidden-recursion pressure; release 0.3.0 adds deterministic, portable contracts and regression coverage.
- Official Claude and OpenAI publication requirements were reviewed against the 0.3.0 package.
- Git remote is `git@github.com:ihabkhaled/AI-Psychiatry.git`.

- [ ] Push the validated `0.3.0` release to `ihabkhaled/AI-Psychiatry` main.
- [x] Add support, privacy, terms, listing copy, logo, and release notes.
- [ ] Build and validate `dist/ai-psychiatry-0.3.0.zip`.
- [ ] Claude local smoke test completed.
- [ ] Claude marketplace submission completed and identifier recorded.
- [ ] Codex local marketplace smoke test completed.
- [ ] Codex Plugins Directory submission completed and identifier recorded.
- [ ] Publisher identity verified.
- [x] Support, privacy, and terms URLs prepared.
- [ ] Vendor approvals recorded before README says "published."
