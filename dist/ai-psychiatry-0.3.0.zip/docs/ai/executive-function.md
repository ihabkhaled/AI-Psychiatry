# Executive Function

This document explains executive function for maintainers. Operational authority remains in the master prompt and focused .ai rules. Use evidence, bounded work, progressive disclosure, and proof-based termination.

